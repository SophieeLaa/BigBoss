using System;
using System.Collections.Generic;

using DevExpress.ExpressApp;
using System.Reflection;


namespace BigBOSS_v2.Module
{
    public sealed partial class BigBOSS_v2Module : ModuleBase
    {
        public BigBOSS_v2Module()
        {
            InitializeComponent();
        }
    }
}
