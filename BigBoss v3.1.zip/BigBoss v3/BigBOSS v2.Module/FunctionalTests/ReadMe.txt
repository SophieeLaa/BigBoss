﻿Folder Description

The "FunctionalTests" project folder is intended for storing EasyTest 
configuration file and scripts.


Relevant Documentation

Functional Testing
http://help.devexpress.com/#Xaf/CustomDocument3206
