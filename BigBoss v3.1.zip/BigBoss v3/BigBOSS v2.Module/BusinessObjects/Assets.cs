using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    public class Assets : BaseObject
    {
        public Assets(Session session)
            : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here or place it only when the IsLoading property is false:
            // if (!IsLoading){
            //    It is now OK to place your initialization code here.
            // }
            // or as an alternative, move your initialization code into the AfterConstruction method.
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }
        public string Name { get; set; }
        public string Model { get; set; }
        public string SerialNumber { get; set; }
        public decimal InnitialPrice { get; set; }
        public decimal MarketPrice { get; set; }
        public decimal RentPrice { get; set; }
        public double AmmortizationIndex { get; set; }
        [Size(SizeAttribute.Unlimited)]
        public string Description { get; set; }
        public OnBalance OnBalance { get; set; }
        public Location Location { get; set; }
        public Condition Condition { get; set; }
        public string Vendor { get; set; }
        public DateTime GetDate { get; set; }
        public DateTime DemageDate { get; set; }
        public DateTime TakeAwayDate { get; set; }
        public DateTime SoldDate { get; set; }
        public InnerLocation InnerLocation { get; set; }

        



    }
    public enum OnBalance {Yes=0, No=1, Rented=2, Sold=3, Demaged=4 }
    public enum Location { InOffice=0, OutDoor=1 }
    public enum InnerLocation { ExecutiveRoom = 0, MarketingDepartment = 1, WebDepartment = 2, CodingHall = 3, Other = 4, }
    public enum Condition { Good=0, Normal=1, Poor=2, Demaged=3, }
}
