using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    [DefaultProperty("Invoice")]
    public class Payments : BaseObject
    {
        public Payments(Session session)
            : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here or place it only when the IsLoading property is false:
            // if (!IsLoading){
            //    It is now OK to place your initialization code here.
            // }
            // or as an alternative, move your initialization code into the AfterConstruction method.
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }
        public decimal Ammount { get; set; }
        [Size(SizeAttribute.Unlimited)]
        public string Comment { get; set; }
        public Banks From { get; set; }
        public string Invoice { get; set; }
        public DateTime InvoiceDate { get; set; }
        public PaidStatus Status { get; set; }
        [Association]
        public Companies Company { get; set; }



        [Association]
        public OfficeMonthleyCharge OfficeMonthleyCharge { get; set; }

        public int Month { get; set; }
        public int Year { get; set; }


        public Releases Releases { get; set; }
        [Association]
        public Contracts Contracts { get; set; }
        public int PaymentPeriod { get; set; }
        private decimal amo;
        public double LateFee { get; set; }
        [ImmediatePostData]
        public DateTime PaymentDate { get; set; }
        public decimal LatePenalty
        {
            get
            {
                if (InvoiceDate.Date != new DateTime(0001, 01, 1))
                {

                    if (PaymentDate.Date == new DateTime(0001, 01, 1))
                    {
                        if ((DateTime.Now.Date - InvoiceDate.AddDays(PaymentPeriod - 1).Date).Days > 0)
                        {
                            amo = (DateTime.Now.Date - InvoiceDate.AddDays(PaymentPeriod - 1).Date).Days * Convert.ToDecimal(LateFee) * Ammount / 100;
                        }
                        else
                        {
                            amo = 0;
                        }
                    }
                    else
                    {
                        if ((PaymentDate.Date - InvoiceDate.AddDays(PaymentPeriod - 1).Date).Days > 0)
                        {
                            amo = (PaymentDate.Date - InvoiceDate.AddDays(PaymentPeriod - 1).Date).Days * Convert.ToDecimal(LateFee) * Ammount / 100;
                        }
                        else
                        {
                            amo = 0;
                        }
                    }
                    return amo;
                }
                return amo;
            }
        }

        protected override void OnChanged(string propertyName, object oldValue, object newValue)
        {

            if (propertyName == "PaymentDate")
            {
                Month = PaymentDate.Month;
                Year = PaymentDate.Year;
            }
            base.OnChanged(propertyName, oldValue, newValue);
        }

    }
    public enum PaidStatus {Registered=0, Paid=1, Processing=2, Potential=3, Exxxxx=4}
}
