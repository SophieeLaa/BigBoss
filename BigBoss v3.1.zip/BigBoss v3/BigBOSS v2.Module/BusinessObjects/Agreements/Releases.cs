using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    public class Releases : BaseObject
    {
        public Releases(Session session)
            : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here or place it only when the IsLoading property is false:
            // if (!IsLoading){
            //    It is now OK to place your initialization code here.
            // }
            // or as an alternative, move your initialization code into the AfterConstruction method.
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }
        public string Name { get; set; }
        public string Version { get; set; }
        [Association]
        public Contracts Contract { get; set; }
        [Size(SizeAttribute.Unlimited)]
        public string Description { get; set; }
        public DateTime ReleaseDate { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DateTime PlannedDate { get; set; }
        [Size(SizeAttribute.Unlimited)]
        public string WhatIsDone { get; set; }
        public FileData Attachment { get; set; }
        public ReleaseStatus Status { get; set; }
        public Payable Payable { get; set; }
        public Payments Paymnets { get; set; }
        public IsTransferRecieving TransferRecieving { get; set; }
        public TransferRecieving TransferRecievingAct { get; set; }

    }
    public enum ReleaseStatus {Registered=0, Processing=1, ToBeDelivered=2, Delivered=3, Accepted=4, Declined=5 }
    public enum Payable { Yes=0, No=1, Maybe=2 }
    public enum IsTransferRecieving { Yes = 0, No = 1, Maybe = 2 }
    
}
