using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    [DefaultProperty("Comment")]
    public class SalaryCharge : BaseObject
    {
        public SalaryCharge(Session session)
            : base(session)
        {
            if (session.IsNewObject(this))
            {
                if (Employee != null)
                {
                    foreach (var item in Employee.CurrentPositions)
                    {

                        if (item.PositionStatus == PositionStatus.Active)
                        {
                            UnderPosition = item;
                        }
                    }

                    if (UnderPosition != null)
                    {
                        Salary = UnderPosition.Salary;
                    }
                }
            }

        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }
        private Employee _Employee;
        private CurrentPositions _UnderPosition;
        private decimal _Salary;
        public string Comment { get; set; }

        [Association]
        public OfficeMonthleyCharge OfficeMonthleyCharge { get; set; }


        [Association]
        [ImmediatePostData(true)]
        public Employee Employee
        {
            get
            {
                return _Employee;
            }
            set
            {
                SetPropertyValue("Employee", ref _Employee, value);
            }
        }
        public DateTime DateCharge { get; set; }
        public DateTime DueDate { get; set; }






        [Association]
        public XPCollection<SalaryPayment> SalaryPayment
        {
            get
            {

                return GetCollection<SalaryPayment>("SalaryPayment");

            }
        }
        private decimal _ToBePayed;
        public decimal ToBePayed
        {
            get
            {
                _ToBePayed = Salary;
                foreach (var item in SalaryPayment)
                {
                    _ToBePayed -= item.Ammount;
                }
                return _ToBePayed;
            }
        }



        [ImmediatePostData(true)]
        public CurrentPositions UnderPosition
        {
            get
            {
                return _UnderPosition;
            }
            set
            {
                SetPropertyValue("UnderPosition", ref _UnderPosition, value);
            }
        }
    [ImmediatePostData(true)]
        public decimal Salary
        {
            get
            {
                return _Salary;
            }
            set
            {
                SetPropertyValue("Salary", ref _Salary, value);
            }
        }

        protected override void OnChanged(string propertyName, object oldValue, object newValue)
        {
            base.OnChanged(propertyName, oldValue, newValue);
            if (propertyName == "Employee")
            {
                foreach (var item in Employee.CurrentPositions)
                {
                    if (item.PositionStatus == PositionStatus.Active)
                    {
                        UnderPosition = item;
                    }
                }

                if (UnderPosition != null)
                {
                    Salary = UnderPosition.Salary;
                }
            }
        }

    }

}
