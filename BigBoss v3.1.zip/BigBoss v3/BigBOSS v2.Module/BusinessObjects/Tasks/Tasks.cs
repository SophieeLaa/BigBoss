﻿using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    [ImageName("015")]
    [DefaultProperty("Oid")]
    public class Tasks : XPObject
    {

        public Tasks(Session session)
            : base(session)
        {
            if (session.IsNewObject(this))
            {
                DatePosted = DateTime.Now;
            }
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }

        public DateTime DatePosted { get; set; }
        public DateTime Deadline { get; set; }
        public Persons Person { get; set; }
        [Size(SizeAttribute.Unlimited)]
        public string Comment { get; set; }
        public Tasks NextTask { get; set; }
        public TaskTypes TaskType { get; set; }
        public Status Status { get; set; }
        public string DaysLeft
        {
            get
            {
                return (DateTime.Now.Date - Deadline.Date).Days.ToString();
            }
        }

    }
    public enum Status { None=0, Bad=1, Good=2, ХуйЗнает=3 }
}

