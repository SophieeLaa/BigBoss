using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;
using System.Collections.Generic;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    [DefaultProperty("OfficeChargeName")]
    public class OfficeMonthleyCharge : BaseObject
    {
        public OfficeMonthleyCharge(Session session)
            : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here or place it only when the IsLoading property is false:
            // if (!IsLoading){
            //    It is now OK to place your initialization code here.
            // }
            // or as an alternative, move your initialization code into the AfterConstruction method.
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }




        public int Month { get; set; }
        public int Year { get; set; }
        [ImmediatePostData]
        public DateTime Date { get; set; }


        public String OfficeChargeName { get; set; }


        [Association]
        public XPCollection<SalaryCharge> SalaryCharge
        {
            get
            {

                return GetCollection<SalaryCharge>("SalaryCharge");

            }
        }



        [Association]
        public XPCollection<Payments> Payments
        {
            get
            {

                return GetCollection<Payments>("Payments");

            }
        }




        //   public IList<Payments> Payments {get; set;}





        [Association]
        public XPCollection<TAX> TAX
        {
            get
            {

                return GetCollection<TAX>("TAX");

            }
        }


        private decimal _TAX;
        public decimal TotalTAX
        {
            get
            {
                _TAX = 0; 
                foreach (var item in SalaryCharge)
                {
                    _TAX += (item.Salary / 100 * 25);
                }
                return _TAX ;
            }
        }



        private decimal _TAX2;
        public decimal ChargedTAX
        {
            get
            {
                _TAX2 = 0;
                foreach (var item in SalaryCharge)
                {
                    foreach (var item2 in item.SalaryPayment)
                    {
                        _TAX2 += (item2.Ammount / 100 * 25);
                    }
                }
                return _TAX2;
            }
        }



        private decimal _TAX3;
        public decimal ToBePayedTAX
        {
            get
            {
                _TAX3 = ChargedTAX;
                    foreach (var item in TAX)
                    {
                        _TAX3 -= item.Ammount;
                    }
                return _TAX3;
            }
        }




        private decimal _TotalSalary;
        public decimal TotalSalary
        {
            get
            {
                _TotalSalary = 0;
                foreach (var item in SalaryCharge)
                {
                    _TotalSalary += item.Salary;
                }
                return _TotalSalary;
            }
        }



        private decimal _Salarytobepayed;
        public decimal SalaryToBePayed
        {
            get
            {
                _Salarytobepayed = 0;
                foreach (var item in SalaryCharge)
                {
                    _Salarytobepayed += item.ToBePayed;
                }
                return _Salarytobepayed;
            }
        }



        private decimal _PayedSalary;
        public decimal PayedSalary
        {
            get
            {
                _PayedSalary = 0;
                foreach (var item in SalaryCharge)
                {
                    foreach (var item2 in item.SalaryPayment) 
                    {
                        _PayedSalary += item2.Ammount;
                    }
                }
                return _PayedSalary;
            }
        }

        protected override void OnChanged(string propertyName, object oldValue, object newValue)
        {

            if (propertyName == "Date")
            {
                Month = Date.Month;
                Year = Date.Year;
            }
            base.OnChanged(propertyName, oldValue, newValue);
        }

    }

}
