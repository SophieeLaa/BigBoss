using System;
using System.ComponentModel;

using DevExpress.Xpo;
using DevExpress.Data.Filtering;

using DevExpress.ExpressApp;
using DevExpress.Persistent.Base;
using DevExpress.Persistent.BaseImpl;
using DevExpress.Persistent.Validation;

namespace BigBOSS_v2.Module.BusinessObjects
{
    [DefaultClassOptions]
    public class Companies : BaseObject
    {
        public Companies(Session session)
            : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here or place it only when the IsLoading property is false:
            // if (!IsLoading){
            //    It is now OK to place your initialization code here.
            // }
            // or as an alternative, move your initialization code into the AfterConstruction method.
        }
        public override void AfterConstruction()
        {
            base.AfterConstruction();
            // Place here your initialization code.
        }
        public string Name { get; set; }
        public string TaxPayerID { get; set; }
        public VAT VAT { get; set; }
        public string Hotline { get; set; }
        public string Website { get; set; }
        public string Address { get; set; }
        [Size(SizeAttribute.Unlimited)]
        public string Comment { get; set; }
        public string AccountNumber { get; set; }
        public Banks Bank { get; set; }
        [Association]
        public XPCollection<Payments> Payments 
        {
            get
            {

             return GetCollection<Payments>("Payments");

            }
        }
        [Association]
        public XPCollection<Contracts> Contracts
        {
            get
            {

                return GetCollection<Contracts>("Contracts");

            }
        }


    }
    public enum VAT { Yes, No }

}
