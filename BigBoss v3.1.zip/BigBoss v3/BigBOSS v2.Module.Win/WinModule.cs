using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

using DevExpress.ExpressApp;

namespace BigBOSS_v2.Module.Win
{
    [ToolboxItemFilter("Xaf.Platform.Win")]
    public sealed partial class BigBOSS_v2WindowsFormsModule : ModuleBase
    {
        public BigBOSS_v2WindowsFormsModule()
        {
            InitializeComponent();
        }
    }
}
