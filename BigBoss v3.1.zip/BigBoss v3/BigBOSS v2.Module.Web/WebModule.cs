using System;
using System.ComponentModel;

using DevExpress.ExpressApp;

namespace BigBOSS_v2.Module.Web
{
    [ToolboxItemFilter("Xaf.Platform.Web")]
    public sealed partial class BigBOSS_v2AspNetModule : ModuleBase
    {
        public BigBOSS_v2AspNetModule()
        {
            InitializeComponent();
        }
    }
}
